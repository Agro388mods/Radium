package net.mcreator.radium.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class RadiumBlockBlock extends Block {
	public RadiumBlockBlock(BlockBehaviour.Properties properties) {
		super(properties.mapColor(MapColor.EMERALD).sound(SoundType.METAL).strength(2f, 30f).lightLevel(s -> 15).requiresCorrectToolForDrops().hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true)
				.instrument(NoteBlockInstrument.BELL));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 7;
	}
}