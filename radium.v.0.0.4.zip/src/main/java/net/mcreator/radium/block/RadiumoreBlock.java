package net.mcreator.radium.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class RadiumoreBlock extends Block {
	public RadiumoreBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(3f, 5f).lightLevel(s -> 3).requiresCorrectToolForDrops());
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 0;
	}
}