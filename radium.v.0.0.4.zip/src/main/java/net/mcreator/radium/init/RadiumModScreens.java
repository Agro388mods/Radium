/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.radium.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.radium.client.gui.ToolGUIScreen;
import net.mcreator.radium.client.gui.ProxyGUIScreen;

@EventBusSubscriber(Dist.CLIENT)
public class RadiumModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(RadiumModMenus.TOOL_GUI.get(), ToolGUIScreen::new);
		event.register(RadiumModMenus.PROXY_GUI.get(), ProxyGUIScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}