/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.radium.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.radium.item.inventory.TuningInventoryCapability;
import net.mcreator.radium.item.TuningItem;
import net.mcreator.radium.item.RadiumShardItem;
import net.mcreator.radium.item.RadiumIngotItem;
import net.mcreator.radium.item.RadiationJuiceItem;
import net.mcreator.radium.block.ProxyBlockBlock;
import net.mcreator.radium.RadiumMod;

import java.util.function.Function;

@EventBusSubscriber
public class RadiumModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(RadiumMod.MODID);
	public static final DeferredItem<Item> RADIUM_INGOT;
	public static final DeferredItem<Item> RADIUM_BLOCK;
	public static final DeferredItem<Item> RADIUMORE;
	public static final DeferredItem<Item> TUNING;
	public static final DeferredItem<Item> RADIATION_JUICE_BUCKET;
	public static final DeferredItem<Item> PROXY_BLOCK;
	public static final DeferredItem<Item> RADIUM_SHARD;
	static {
		RADIUM_INGOT = register("radium_ingot", RadiumIngotItem::new);
		RADIUM_BLOCK = block(RadiumModBlocks.RADIUM_BLOCK, new Item.Properties().rarity(Rarity.RARE));
		RADIUMORE = block(RadiumModBlocks.RADIUMORE, new Item.Properties().rarity(Rarity.RARE));
		TUNING = register("tuning", TuningItem::new);
		RADIATION_JUICE_BUCKET = register("radiation_juice_bucket", RadiationJuiceItem::new);
		PROXY_BLOCK = register("proxy_block", properties -> new ProxyBlockBlock.Item(properties.rarity(Rarity.RARE)));
		RADIUM_SHARD = register("radium_shard", RadiumShardItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new TuningInventoryCapability(stack), TUNING.get());
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), RADIATION_JUICE_BUCKET.get());
	}
}