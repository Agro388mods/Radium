/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.radium.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.radium.block.RadiumoreBlock;
import net.mcreator.radium.block.RadiumBlockBlock;
import net.mcreator.radium.block.RadiationJuiceBlock;
import net.mcreator.radium.block.ProxyBlockBlock;
import net.mcreator.radium.RadiumMod;

import java.util.function.Function;

public class RadiumModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(RadiumMod.MODID);
	public static final DeferredBlock<Block> RADIUM_BLOCK;
	public static final DeferredBlock<Block> RADIUMORE;
	public static final DeferredBlock<Block> RADIATION_JUICE;
	public static final DeferredBlock<Block> PROXY_BLOCK;
	static {
		RADIUM_BLOCK = register("radium_block", RadiumBlockBlock::new);
		RADIUMORE = register("radiumore", RadiumoreBlock::new);
		RADIATION_JUICE = register("radiation_juice", RadiationJuiceBlock::new);
		PROXY_BLOCK = register("proxy_block", ProxyBlockBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}