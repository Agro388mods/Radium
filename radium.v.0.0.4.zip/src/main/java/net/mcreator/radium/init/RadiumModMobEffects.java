/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.radium.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.radium.potion.RadiationpoisonMobEffect;
import net.mcreator.radium.RadiumMod;

public class RadiumModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, RadiumMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> RADIATION_POISON = REGISTRY.register("radiation_poison", () -> new RadiationpoisonMobEffect());
}