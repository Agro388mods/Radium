/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.radium.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.radium.fluid.RadiationJuiceFluid;
import net.mcreator.radium.RadiumMod;

public class RadiumModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, RadiumMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> RADIATION_JUICE = REGISTRY.register("radiation_juice", () -> new RadiationJuiceFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_RADIATION_JUICE = REGISTRY.register("flowing_radiation_juice", () -> new RadiationJuiceFluid.Flowing());

	@EventBusSubscriber(Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(RADIATION_JUICE.get(), ChunkSectionLayer.TRANSLUCENT);
			ItemBlockRenderTypes.setRenderLayer(FLOWING_RADIATION_JUICE.get(), ChunkSectionLayer.TRANSLUCENT);
		}
	}
}