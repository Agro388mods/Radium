/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.radium.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.radium.RadiumMod;

public class RadiumModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RadiumMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> RADIUM = REGISTRY.register("radium",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.radium.radium")).icon(() -> new ItemStack(RadiumModItems.RADIUM_INGOT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RadiumModItems.RADIUM_INGOT.get());
				tabData.accept(RadiumModBlocks.RADIUM_BLOCK.get().asItem());
				tabData.accept(RadiumModBlocks.RADIUMORE.get().asItem());
				tabData.accept(RadiumModItems.TUNING.get());
				tabData.accept(RadiumModItems.RADIATION_JUICE_BUCKET.get());
				tabData.accept(RadiumModBlocks.PROXY_BLOCK.get().asItem());
				tabData.accept(RadiumModItems.RADIUM_SHARD.get());
			}).build());
}