/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.radium.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.radium.RadiumMod;

public class RadiumModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, RadiumMod.MODID);
	public static final DeferredHolder<Potion, Potion> RADIATION = REGISTRY.register("radiation", () -> new Potion("radiation", new MobEffectInstance(RadiumModMobEffects.RADIATION_POISON, 3600, 0, false, true)));
}