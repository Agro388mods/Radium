/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.radium.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.radium.fluid.types.RadiationJuiceFluidType;
import net.mcreator.radium.RadiumMod;

public class RadiumModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, RadiumMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> RADIATION_JUICE_TYPE = REGISTRY.register("radiation_juice", () -> new RadiationJuiceFluidType());
}