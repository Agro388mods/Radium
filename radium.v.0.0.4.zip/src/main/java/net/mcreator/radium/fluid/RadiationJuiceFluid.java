package net.mcreator.radium.fluid;

import org.apache.logging.log4j.core.util.Source;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.radium.init.RadiumModItems;
import net.mcreator.radium.init.RadiumModFluids;
import net.mcreator.radium.init.RadiumModFluidTypes;
import net.mcreator.radium.init.RadiumModBlocks;

public abstract class RadiationJuiceFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> RadiumModFluidTypes.RADIATION_JUICE_TYPE.get(), () -> RadiumModFluids.RADIATION_JUICE.get(), () -> RadiumModFluids.FLOWING_RADIATION_JUICE.get())
			.explosionResistance(100f).bucket(() -> RadiumModItems.RADIATION_JUICE_BUCKET.get()).block(() -> (LiquidBlock) RadiumModBlocks.RADIATION_JUICE.get());

	private RadiationJuiceFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.DRIPPING_WATER;
	}

	public static class Source extends RadiationJuiceFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends RadiationJuiceFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}