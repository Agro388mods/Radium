package net.mcreator.radium.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class RadiumIngotItem extends Item {
	public RadiumIngotItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE).stacksTo(32).food((new FoodProperties.Builder()).nutrition(-10).saturationModifier(-2f).alwaysEdible().build()));
	}
}