package net.mcreator.radium.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.radium.init.RadiumModFluids;

public class RadiationJuiceItem extends BucketItem {
	public RadiationJuiceItem(Item.Properties properties) {
		super(RadiumModFluids.RADIATION_JUICE.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.RARE));
	}
}