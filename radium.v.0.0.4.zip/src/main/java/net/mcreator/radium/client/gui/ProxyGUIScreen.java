package net.mcreator.radium.client.gui;

import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.client.gui.widget.ExtendedSlider;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.radium.world.inventory.ProxyGUIMenu;
import net.mcreator.radium.network.ProxyGUIButtonMessage;
import net.mcreator.radium.init.RadiumModScreens;

public class ProxyGUIScreen extends AbstractContainerScreen<ProxyGUIMenu> implements RadiumModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_close;
	private ImageButton imagebutton_model_2;
	private ExtendedSlider slider;

	public ProxyGUIScreen(ProxyGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		if (elementType == 2 && elementState instanceof Number n) {
			if (name.equals("slider"))
				slider.setValue(n.doubleValue());
		}
		menuStateUpdateActive = false;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("radium:textures/screens/proxy_gui.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
		return (this.getFocused() != null && this.isDragging() && button == 0) ? this.getFocused().mouseDragged(mouseX, mouseY, button, dragX, dragY) : super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
	}

	@Override
	public void init() {
		super.init();
		button_close = Button.builder(Component.translatable("gui.radium.proxy_gui.button_close"), e -> {
			int x = ProxyGUIScreen.this.x;
			int y = ProxyGUIScreen.this.y;
			if (true) {
				ClientPacketDistributor.sendToServer(new ProxyGUIButtonMessage(0, x, y, z));
				ProxyGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 116, this.topPos + 57, 51, 20).build();
		this.addRenderableWidget(button_close);
		imagebutton_model_2 = new ImageButton(this.leftPos + 153, this.topPos + 5, 16, 16, new WidgetSprites(ResourceLocation.parse("radium:textures/screens/model_2.png"), ResourceLocation.parse("radium:textures/screens/model_2.png")), e -> {
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
				guiGraphics.blit(RenderPipelines.GUI_TEXTURED, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		this.addRenderableWidget(imagebutton_model_2);
		slider = new ExtendedSlider(this.leftPos + 11, this.topPos + 34, 46, 20, Component.translatable("gui.radium.proxy_gui.slider_prefix"), Component.translatable("gui.radium.proxy_gui.slider_suffix"), 0, 32, 32, 1, 0, true) {
			@Override
			protected void applyValue() {
				if (!menuStateUpdateActive)
					menu.sendMenuStateUpdate(entity, 2, "slider", this.getValue(), false);
			}
		};
		this.addRenderableWidget(slider);
		if (!menuStateUpdateActive)
			menu.sendMenuStateUpdate(entity, 2, "slider", slider.getValue(), false);
	}
}