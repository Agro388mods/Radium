package net.mcreator.radium.procedures;

public class ChangeProcedure {
	public static void execute() {
	}
}